console.log("10 + 20 =", 10 + 20);
console.log("33 + 55 =", 33 + 55);

const os = require('os');

console.log("Platform:", process.platform);
console.log("Node.js Version:", process.version);
console.log("OS Type:", os.type());
console.log("User Info:", os.userInfo());