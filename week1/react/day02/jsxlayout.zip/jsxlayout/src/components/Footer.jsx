function Footer(){
    return(
        <div>
            <h2 style={{border:"2px solid green", padding:"20px", backgroundColor:"lavender", position:"fixed", bottom:0, width:"100%"}}>Footer</h2>
        </div>
    )
}

export default Footer;