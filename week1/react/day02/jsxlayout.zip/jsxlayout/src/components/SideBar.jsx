function SideBar(){
    return(
        <div>
            <h2 style={{width:"200px", border:"2px solid brown",backgroundColor:"lightpink", height:"800px"}}>SideBar</h2>
        </div>
    )
}
export default SideBar;