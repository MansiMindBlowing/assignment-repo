function Cards(){
    return(
        <div style={{display:"flex",flexWrap:"wrap", justifyContent:"center",alignItems:"flex-start", flex:1, height:"100px"}}>
           <div style={{width:"200px", height:"150px", backgroundColor:"wheat", border:"2px solid black", margin:"20px", padding:"20px"}}>card1</div>
            <div style={{width:"200px", height:"150px", backgroundColor:"wheat", border:"2px solid black", margin:"20px", padding:"20px"}}>card1</div>
             <div style={{width:"200px", height:"150px", backgroundColor:"wheat", border:"2px solid black", margin:"20px", padding:"20px"}}>card1</div>
        </div>
    )
}
export default Cards